package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private EditText editDobasok;
    private Button buttonSzimulal;
    private TextView textValos, textElmeleti, textGyakorisag;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editDobasok = findViewById(R.id.editDobasok);
        buttonSzimulal = findViewById(R.id.buttonSzimulal);
        textValos = findViewById(R.id.textValos);
        textElmeleti = findViewById(R.id.textElmeleti);
        textGyakorisag = findViewById(R.id.textGyakorisag);

        buttonSzimulal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int N = Integer.parseInt(editDobasok.getText().toString());
                int hetesek = 0;
                int[] gyakorisagok = new int[13];  // 0-12

                for (int i = 0; i < N; i++) {
                    int d1 = random.nextInt(6) + 1;
                    int d2 = random.nextInt(6) + 1;
                    int osszeg = d1 + d2;
                    gyakorisagok[osszeg]++;
                    if (osszeg == 7) hetesek++;
                }

                double valosP = (hetesek * 100.0) / N;
                textValos.setText(String.format("Valós P(7): %.1f%%", valosP));

                StringBuilder sb = new StringBuilder("Gyakoriságok:\n");
                for (int i = 2; i <= 12; i++) {
                    double p = (gyakorisagok[i] * 100.0) / N;
                    sb.append(i).append(": ").append(String.format("%.1f%% ", p));
                }
                textGyakorisag.setText(sb.toString());
            }
        });
    }
}